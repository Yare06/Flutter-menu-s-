package com.yarely.lateral_navi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
