package com.yarely.bottom_navi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
