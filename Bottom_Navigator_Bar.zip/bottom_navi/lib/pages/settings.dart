import 'package:flutter/material.dart';

class Settings extends StatelessWidget {
  const Settings({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(child: Text('Bienvenidos a Settings', style: TextStyle(fontSize: 22.0, fontWeight: FontWeight.bold,color: Colors.purple),),);
  }
}